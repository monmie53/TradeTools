# TradeTools (iOS)
SwiftUI app: position size calculator (XAUUSD default), R:R calculator, ICT killzone clock (NY time).

## Build the .ipa (needs a Mac with Xcode)
1. `brew install xcodegen && cd TradeTools && xcodegen` -> creates TradeTools.xcodeproj
2. Open it in Xcode, set your Team under Signing & Capabilities.
3. Product > Archive > Distribute App > Ad Hoc / Development > Export -> .ipa
   (or via CLI: xcodebuild archive, then xcodebuild -exportArchive with an ExportOptions.plist)
4. Install: Xcode Devices window, Apple Configurator, or Sideloadly/AltStore with a free Apple ID.

## No Mac? Build unsigned IPA on GitHub (free)
1. Create a GitHub repo and upload the contents of this folder (project.yml must be at the repo root, plus the .github folder).
2. Actions tab > "Build unsigned IPA" > Run workflow.
3. Download the TradeTools-ipa artifact, unzip it to get TradeTools.ipa.
4. In ESign: import the .ipa, add your own certificate (.p12 + .mobileprovision + password), sign, then install.
